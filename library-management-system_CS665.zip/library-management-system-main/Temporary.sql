create database library_management;
create table book_list(
	book_id VARCHAR(10) NOT NULL,
	book_name VARCHAR(50) NOT NULL,
	author VARCHAR(50) NOT NULL,
	edition VARCHAR(10) NOT NULL,
	price Int(6) NOT NULL,
	qty Int(4) NOT NULL,
	PRIMARY KEY ( book_id )
);
create table borrow_record(
	book_id VARCHAR(10) NOT NULL,
	book_name VARCHAR(50) NOT NULL,
	stu_roll VARCHAR(15) NOT NULL,
	stu_name VARCHAR(50) NOT NULL,
	course VARCHAR(10) NOT NULL,
	subject VARCHAR(30) NOT NULL,
	issue_date date NOT NULL,
	return_date date NOT NULL
);

INSERT INTO book_list
		(book_id, book_name,author,edition,price,qty)
		VALUES 
		('1','The Name of the Wind', 'DAW Books','2 edition',36,21),
		('2','It', 'Viking','1 edition',41,12),
		('3','The Green Mile', 'Signet Books','1 edition',24,5),
		('4','Dune', 'Chilton Books','3 edition',42,4),
		('5','The Hobbit', 'George Allen & Unwin','2 edition',27,3);

INSERT INTO borrow_record
		(book_id, book_name,stu_roll,stu_name,course,subject,issue_date, return_date)
		VALUES
		('1','The Name of the Wind','21','Joe Smith','DS','Database','10-11-22','20-11-22'),
		('2','It','1','Anna Smith','DS','Database','10-11-22','20-11-22'),
        ('3','The Green Mile','45','Chloe Smith','DS','Database','10-11-22','20-11-22'),
        ('4','Dune','213','Sam Smith','DS','Database','10-11-22','20-11-22')
        ;
		


